# Phumza Sotyantya Portfolio

This is my personal portfolio website showcasing my skills, projects, and contact information.

## Features
- Professional Portfolio Website
- Standardized Project Documentation
- Minimum of 3 Featured Projects with Links
- Technical Skills and Competencies Section
- Downloadable Resume

## Live Site
(Provide the GitHub Pages link after deployment)

## Contact
[LinkedIn Profile](https://za.linkedin.com/in/phumza-sotyantya-44929427a)
